import React, { useState } from "react"
import "./App.scss";

import AppHeader from "./modules/header/header";
import LoginForm from "./modules/loginForm/loginForm";

export default function App() {
  const [isLogged, setIsLogged] = useState(false)

  return (
      <div className="MyCloud">
        <AppHeader isLogged={isLogged} setIsLogged={setIsLogged} />
        {!isLogged ? <LoginForm /> : <></>}
      </div>
  );
}
