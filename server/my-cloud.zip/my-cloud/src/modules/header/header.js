import React from "react";
import "./header.scss";
import Button from "@mui/material/Button";

export default function AppHeader(props) {
  const { isLogged, setIsLogged } = props;

  const handleLogOut = async () => {
	setIsLogged(false)
  }

  return (
	  <header className="header">
		  <h2 variant="h5">My Cloud</h2>
		  {!isLogged && (
			  <Button onClick={handleLogOut} color="inherit">
				  LogOut
			  </Button>
		  )}
	  </header>
  );
}
