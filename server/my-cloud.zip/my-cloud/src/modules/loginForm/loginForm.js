import React, { useState } from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import "./loginForm.scss";
import { logIn } from "./loginForm.service";

const EMAIL_REGEX =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

export default function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [emailHasError, setEmailHasError] = useState(false);
  const [passwordHasError, setPasswordHasError] = useState(false);

  const validateEmail = () => {
    setEmailHasError(!EMAIL_REGEX.test(email));
  };

  const handleLogIn = () => {
	if (email === '') {
		setEmailHasError(true)
	}
	if (password === '') {
		setPasswordHasError(true)
	}

	if (emailHasError || passwordHasError) {
		return 
	}

    logIn(email, password);
  };

  return (
    <div className="loginForm">
      <span className="loginFormInput">
        <TextField
          id="userEMail"
          label="e-mail"
          variant="standard"
          error={emailHasError}
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          onBlur={validateEmail}
        />
        {emailHasError ? (
          <p className="loginFormInputError">
            Please enter a valid email address
          </p>
        ) : null}
      </span>
      <span className="loginFormInput">
        <TextField
          id="userPassword"
          label="Password"
          type="password"
          autoComplete="current-password"
          variant="standard"
          error={passwordHasError}
		  value={password}
		  onChange={(event) => setPassword(event.target.value)}
        />
		{passwordHasError ? (
          <p className="loginFormInputError">
            Please enter a valid password
          </p>
        ) : null}
      </span>
      <div className="loginFormButtonWrapper">
        <Button
          onClick={handleLogIn}
          variant="outlined"
          disabled={emailHasError || passwordHasError}
        >
          LogIn
        </Button>
      </div>
    </div>
  );
}
