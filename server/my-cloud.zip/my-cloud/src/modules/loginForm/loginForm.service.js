export function logIn(email, password) {
  const requestBody = {
    email,
    password,
  };

  fetch("/login", {
    method: "POSt",
    mode: "cors",
    cache: "no-cache",
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestBody),
  }).then((response) => {
    return console.log(response);
  });
}
